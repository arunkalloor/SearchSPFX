import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
import { SPConnector } from './SPDL';
declare global {
    interface Window {
        exceuteOnce: Object;
        exceuteOnce_anim: any;
    }
}
export interface IFedBankSearchWpWebPartProps {
    description: string;
}
export default class FedBankSearchWpWebPart extends BaseClientSideWebPart<IFedBankSearchWpWebPartProps> {
    spa: SPConnector;
    protected onInit(): Promise<void>;
    render(): void;
    private basicInit;
    private setupEventHandlers;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=FedBankSearchWpWebPart.d.ts.map