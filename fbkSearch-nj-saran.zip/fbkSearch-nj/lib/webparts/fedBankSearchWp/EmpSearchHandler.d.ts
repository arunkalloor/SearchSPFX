export declare class EmpSearch {
    static onload(): void;
    static onFirstSearch(): void;
    static getEmpList(dataObj: any): void;
    static createEmpListTable(empList_arr: any): void;
    static getEmpDetails(data: any, clear_table: any): void;
    static createEmpDetailsCard(empDetails_arr: any, clear_table: any): void;
    static cardOnSameLine(): void;
    static removeCard(): void;
    static getMoreEmpDetails(data: any): void;
    static showMoreDetailsModal(empJson: any): void;
    static getBranchDetails(data: any): void;
    static showBranchModal(branchJson: any): void;
    static copyToClipboard(element: any): void;
}
//# sourceMappingURL=EmpSearchHandler.d.ts.map