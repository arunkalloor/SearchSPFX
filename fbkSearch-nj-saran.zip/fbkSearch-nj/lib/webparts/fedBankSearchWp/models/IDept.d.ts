interface IDepartment {
    DEPTCODE: string;
    SOLID: string;
    DEPTDESC: string;
}
//# sourceMappingURL=IDept.d.ts.map