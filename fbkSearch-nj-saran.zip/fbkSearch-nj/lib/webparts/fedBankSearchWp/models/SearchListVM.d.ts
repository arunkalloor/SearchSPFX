interface ISearchListItemVM {
    NAME: string;
    CODE: string;
    TYPE: string;
}
//# sourceMappingURL=SearchListVM.d.ts.map