interface IDesignation {
    DESIGCODE: string;
    DESIGDESC: string;
    SCALE: string;
}
//# sourceMappingURL=IDesig.d.ts.map