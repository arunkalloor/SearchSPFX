export declare class SPConnector {
    private static readonly VCARD_TABLE;
    private static readonly DEPT_TABLE;
    private static readonly BRANCH_TABLE;
    private searchTable;
    private withImageItems;
    getEmpData(queryStr: string, callback: any): string;
    getEmpDataM(query: string, callback: any): void;
    getEmpMoreDetails(query: string, callback: any): void;
    getBranchDetails(query: string, callback: any): void;
    private fetchImageForItem;
    private fetchImagesForItems;
    private settleAllPromise;
    private getImgSrc;
    private fillMoreDetails;
    private getVcards;
    private addDeptSld;
    private addDeptDesc;
    private addDept03;
    private addEmpName;
    private addEmpMob;
    private addEmpPFN;
    private addEmpOff;
}
//# sourceMappingURL=SPDL.d.ts.map