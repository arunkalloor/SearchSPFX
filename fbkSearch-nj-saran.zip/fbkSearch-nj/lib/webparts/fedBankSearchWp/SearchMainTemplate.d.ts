export default class htmlMain {
    static htmlTemplateStr: string;
}
//# sourceMappingURL=SearchMainTemplate.d.ts.map