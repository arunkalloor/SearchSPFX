import * as  jQuery from 'jquery';
import * as M from 'materialize-css';

export class EmpSearch {

  public static  onload() {
    $('.first-wrap').append($('.preloader-wrapper').hide());
  }

  public static  onFirstSearch() {
    if ($('#searchTxt').val()) {
      $(".searchDiv").addClass("z-depth-4");
      $(".first-wrap").addClass("reduced");
      $(".info,.footer-copyright").fadeOut();
      //** remove nav bar */
      $("nav").animate({
        height: "0px",
        // tslint:disable-next-line: no-function-expression
      }, 1200, 'easeInOutExpo', function () {
        $('nav').hide();
      });
      //** show logo inside search block */
      $(".searchDiv a.brand-logo").animate({
        opacity: "1"
      }, 1900, 'easeInOutExpo');
      //** move search from to top */
      $(".searchDiv form").animate({
        paddingTop: "0vh"
      }, 1200, 'easeInOutExpo');
      //** reduce the height of input field */
      $(".searchDiv form .inner-form .input-field").animate({
        height: "50px"
      }, 1200, 'easeInOutExpo');
      //** reduce the height of search block */
      $(".searchDiv").animate({
        height: "12vh",
      }, 1000, 'easeInOutExpo');
    }
  }

  public static  getEmpList(dataObj: any) {

    if (window.exceuteOnce_anim) {
      EmpSearch.onFirstSearch();
      window.exceuteOnce_anim = false;
    } else {
      EmpSearch.removeCard();
    }
    EmpSearch.createEmpListTable(dataObj);
  }

  public static createEmpListTable(empList_arr: any) {
    //console.log(JSON.stringify(empList_arr, null, 2));
    $("#result_count").html('<span>' + empList_arr.length + '</span> results');
    $('.preloader-wrapper').hide();
    if (empList_arr.length) {
      //empList_arr = isNaN($('#searchTxt').val())? empList_arr : empList_arr.reverse(); //--sk
      empList_arr = ($('#searchTxt').val()) ? empList_arr : empList_arr.reverse();
      /*empList_arr = isNaN($('#searchTxt').val())? empList_arr : empList_arr.sort(function(a, b) {
          return parseFloat(a.CODE) - parseFloat(b.CODE);
      });*/
      var tableContent = '';
      for (var i = 0; i < empList_arr.length; i++) {
        var row = empList_arr[i];
        var branch_var = '',
          underline_expand = '';
        if ($.inArray(row.TYPE.trim().toLowerCase(), ['solid', 'office', 'office code']) !== -1) {
          branch_var = 'class="blu get_BrnchDetails" data-branch="' + row.CODE.trim() + '"';
          underline_expand = 'class="underline-expand"';
        }
        row.NAME = row.NAME.trim().replace(/\//g, "/ ");
        tableContent += '<tr><td data-code="' + row.CODE.trim() + '" class="list">' + row.CODE.trim() + '</td>' +
          '<td data-code="' + row.CODE.trim() + '" class="list">' + row.NAME.trim() + '</td>' +
          '<td ' + branch_var + '><span ' + underline_expand + '>' + row.TYPE.trim() + '</span></td></tr>';
      }
      //** add list to table body */
      $('#empList_table tbody').html(tableContent);
      //** show table */
      $('.empList').fadeIn("fast");
    } else {
      //** No Result Found
      //$('.empList').fadeOut("fast");
      $("#empList_table tbody").html('<div class="valign-wrapper"><img class="responsive-img no_result" src="img/no_result.gif"><div>');
      //$('.empDetails').fadeOut("slow");
    }
  }

  public static getEmpDetails(data, clear_table) {

    //console.log("in cb " + data);
    //console.log(clear_table);

    EmpSearch.createEmpDetailsCard(data, clear_table);
    return;
  }

  public static createEmpDetailsCard(empDetails_arr, clear_table) {
    /** clear left table if the branch code click on right card
     * clear_table = 1 */
    if (clear_table) {
      var tableContent = '<tr><td>' + empDetails_arr[0].DEPARTTMENT.trim() + '</td>' +
        '<td data-code="' + empDetails_arr[0].DEPARTTMENT.trim() + '" class="list">' + empDetails_arr[0].DEPTDESC.trim() + '</td>' +
        '<td class="blu get_BrnchDetails" data-branch="' + empDetails_arr[0].DEPARTTMENT.trim() + '"><span class="underline-expand"> Office Code </span></td></tr>';
      $('#empList_table tbody').html(tableContent);
    }
    var li_content = '';
    //console.log(JSON.stringify(empDetails_arr,null,2));
    for (var i = 0; i < empDetails_arr.length; i++) {
      var row = empDetails_arr[i];
      //** check BRANCHHEAD flag*/
      var star = (row.BRANCHHEAD == 'Y') ? ' <i class="material-icons">star_border</i>' : '';
      var golden_border = (row.BRANCHHEAD == 'Y') ? 'golden' : '';
      row.EMAIL = row.EMAIL.trim().replace(/[&\/\\,;:]/g, ",</br>");
      //** club */
      var club = '', onleave = '';
      switch (row.CLUB) {
        case "P":
          club = '<div class="chip" id="CLUB">' +
            '<i class="material-icons z-depth-2">star</i> Member-President&apos;s Club</div>';
          break;
        case "E":
          club = '<div class="chip" id="CLUB">' +
            '<i class="material-icons z-depth-2">star_half</i> Member-ED&apos;s Club</div>';
          break;
        case "M":
          club = '<div class="chip" id="CLUB">' +
            '<i class="material-icons z-depth-2">stars</i> Member-MD&apos;s Club</div>';
          break;
      }

      switch (row.ONLEAVE) {
        case "V":
          onleave = '<div class="chip ONLEAVE">' +
            '<i class="material-icons z-depth-2">account_circle</i> Submitted VRS</div>';
          break;
        case "R":
          onleave = '<div class="chip ONLEAVE">' +
            '<i class="material-icons z-depth-2">account_circle</i> Submitted Resignation';
          break;
        case "M":
          onleave = '<div class="chip ONLEAVE">' +
            '<i class="material-icons z-depth-2">account_circle</i> On Leave';
          break;
        case "S":
          onleave = '<div class="chip ONLEAVE">' +
            '<i class="material-icons z-depth-2">account_circle</i> Sabbatical';
          break;
      }
      if (row.SUSPENSION.toUpperCase() == 'SUSPENDED') {
        onleave = '<div class="chip SUSPENDED">' +
          '<i class="material-icons z-depth-2">account_circle</i> Suspended';
      }

      row.RESPONSIBILITY = (row.RESPONSIBILITY == 'N/A') ? '' : '' + row.RESPONSIBILITY.toLowerCase();

      li_content += '<li >' +
        '<div class="row">' +
        '<div class="col s12 ">' +
        '<div class="card horizontal hoverable ' + golden_border + '">' +
        '<div class="card-image">' +
        //'<img src="' + img_path + row.PFNUM.trim() + '.jpg">' +
        '<img src=' + row.imgUrl + '>' +
        '<div data-empcode="' + row.PFNUM.trim() + '" class="card-action">' +
        '<a  class="btn">More <i class="material-icons">keyboard_arrow_right</i></a>' +
        '</div>' +
        '</div>' +
        '<div class="card-stacked">' +
        '<div class="card-content">' +
        '<h5 id="NAME">' + row.NAME.trim() + star +
        '<span id="PFNUM"> (' + row.PFNUM.trim() + ') </span>' +
        '</h5>' +
        '<div class="section2card">' +
        '<div id="DESIGDESC">' + row.DESIGDESC.trim() + '</div>' +
        //'<div id="DEPTDESC" class="get_BrnchDetails anim_btn" data-branch="' + row.DEPARTTMENT + '"><span><span><span>' + row.DEPTDESC.trim().toLowerCase() + ' - ' + row.DEPARTTMENT + '</span></span></span></div>' +
        '<div id="DEPTDESC"><div class="get_BrnchDetails anim_btn" data-branch="' + row.DEPARTTMENT + '"><span><span><span>' + row.DEPTDESC.trim().toLowerCase() + ' </span></span></span></div><div class="dept_sp"> - <span data-code="' + row.DEPARTTMENT + '" class="list underline-expand">' + row.DEPARTTMENT + '</span></div></div>' +
        '<div id="RESPONSIBILITY">' + row.RESPONSIBILITY.trim() + '</div>' +
        '</div>' +
        '<div class="section3card">' +
        '<div>' +
        '<i class="material-icons">work</i>' +
        '<span id="ACTIVITIES_HANDLED">' + row.ACTIVITIES_HANDLED.trim() + '</span>' +
        '</div>' +
        '<div>' +
        '<i class="material-icons">phone</i>' +
        '<span id="OFFICE_NO">' + row.OFFICE_NO.trim() + '</span>' +
        '<i class="material-icons">settings_phone</i>' +
        '<span id="OTHEROFFICENO">' + row.OTHEROFFICENO.trim() + '</span>' +
        '</div>' +
        '<div class="copy_icon_div">' +
        '<i class="material-icons">phone_iphone</i>' +
        '<span class="copy_icon_parent"><span id="MOBILE_NO" class="copy_text">' + row.MOBILE_NO.trim() + '</span><i class="material-icons copy_icon">content_copy</i></span>' +
        '</div>' +
        '<div class="copy_icon_div">' +
        '<i class="material-icons">mail_outline</i>' +
        '<a href="mailto:' + row.EMAIL.trim() + '" class="copy_icon_parent"><span id="EMAIL" class="copy_text">' + row.EMAIL.trim() + '</span><i class="material-icons copy_icon">content_copy</i></a>' +
        '</div>' +
        '</div>' +
        club +
        onleave +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '</li>';
    }
    $('#empDetails_ul').html(li_content);
    $('.empDetails').show();
    //$('#empDetails_ul').showStaggeredList()
    EmpSearch.cardOnSameLine();

  }
  public static  cardOnSameLine() {
    //** empList to 50% and align to same line */

    //SK- this StaggeredList not in 1.0
    setTimeout(() => {
      //M.showStaggeredList('#empDetails_ul');

    }, 500);

    if (window.exceuteOnce) {
      if ($(window).width() > 950) {

        $(".main-content .empList").animate({
          width: "50%",
          // tslint:disable-next-line: no-function-expression
        }, 1000, 'easeInOutExpo').addClass(function () {
          //** remove conatiner */
          $(".main-content .empList .container").animate({
            width: "100%",
          }, 0, 'easeInOutExpo');
          return 'same-row';
        });

        window.exceuteOnce = false;
      }
    }
  }

  public static removeCard() {
    //** remove card only show mail table
    window.exceuteOnce = true;
    $('.empDetails').fadeOut();
    $(".main-content .empList").animate({
      width: "100%",
      // tslint:disable-next-line: no-function-expression
    }, 1000, 'easeInOutExpo').removeClass(function () {
      //** remove conatiner */
      $(".main-content .empList .container").animate({
        width: "70%",
      }, 0, 'easeInOutExpo');
      return 'same-row';
    });
  }

  public  static getMoreEmpDetails(data) {
    EmpSearch.showMoreDetailsModal(data);
  }

  public static showMoreDetailsModal(empJson) {
    //console.log(JSON.stringify(empJson,null ,2));
    /* Formating values */
    empJson.OTHEROFFICENO = (empJson.OTHEROFFICENO == 'N/A') ? '' : ', ' + empJson.OTHEROFFICENO;
    //empJson.REPORTINGPFNO = (empJson.REPORTINGPFNO == 'N/A') ? '' : ' ('+empJson.REPORTINGPFNO+')';
    empJson.EMAIL = empJson.EMAIL.replace(/[&\/\\,;:]/g, ", ");
    var res_address_json = {
      address1: empJson.RESIDENTIAL_ADDRESS1,
      address2: empJson.RESIDENTIAL_ADDRESS2,
      address3: empJson.RESIDENTIAL_ADDRESS3,
      district: empJson.RESIDENTIAL_DISTRICT,
      state: empJson.RESIDENTIAL_STATE,
      country: empJson.RESIDENTIAL_COUNTRY,
      pin: empJson.RESIDENTIAL_PIN
    };
    var res_address = '';
    // tslint:disable-next-line: no-function-expression
    $.each(res_address_json, function (key, val) {
      res_address += (val == 'N/A') ? '' : val + ', ';
    });
    res_address = res_address.slice(0, -2);

    var office_address_json = {
      address1: empJson.OFFICIAL_ADDRESS1,
      address2: empJson.OFFICIAL_ADDRESS2,
      address3: empJson.OFFICIAL_ADDRESS3,
      district: empJson.OFFICIAL_DISTRICT,
      state: empJson.STATE_OFFICIAL,
      country: empJson.COUNTRY,
      pin: empJson.OFFICIAL_PIN
    };
    var office_address = '';
    // tslint:disable-next-line:no-function-expression
    $.each(office_address_json, function (key, val) {
      office_address += (val == 'N/A') ? '' : val + ', ';
    });
    office_address = office_address.slice(0, -2).replace(/,*,/g, ',');

    var modal_content = '<div class="row modal-content">' +
      '      <div id="m_PFNUM_t" class="bg_pfnum">' + empJson.PFNUM + '</div>' +
      '      <div id="contact_left_side" class="col s12 m4">' +
      '        <div id="basic_details" class="center">' +
      '          <div class="profile section">' +
      //'            <img src="' + img_path + empJson.PFNUM.trim() + '.jpg">' +
      '            <img src=' + empJson.imgUrl + '>' +
      '          </div>' +
      '          <div class="section">' +
      '            <h4 id="m_NAME">' + empJson.NAME + '</h4>' +
      '            <div id="m_PFNUM">(' + empJson.PFNUM + ')</div>' +
      '            <div id="m_DESIGDESC">' + empJson.DESIGDESC + '</div>' +
      '            <div id="m_DEPTDESC">' + empJson.DEPTDESC.toLowerCase() + '</div>' +
      '          </div>' +
      '        </div>' +
      //'        <div id="reporting_officer" class="section">' +
      //'          <h6>Reporting Officer</h6>' +
      //'          <div id="m_REPORTTINGPF">' + empJson.REPORTTINGPF +
      //'            <span id="m_REPORTINGPFNO">' + empJson.REPORTINGPFNO + '</span>' +
      //'          </div>' +
      //'        </div>' +
      '      </div>' +
      '      <div class="col s12 m8">' +
      '        <div id="activity_details">' +
      '          <div class="col s12">' +
      '            <div class="section">' +
      '              <i class="material-icons">work</i>' +
      '              <div class="icon_val">' +
      '                <h6>Job Role</h6>' +
      '              </div>' +
      '              <div id="m_ACTIVITIES_HANDLED">' + empJson.ACTIVITIES_HANDLED +
      '              </div>' +
      '            </div>' +
      '            <div class="section" id="mail_section">' +
      '              <i class="material-icons">mail_outline</i>' +
      '              <div class="icon_val">' +
      '                <h6>Email</h6>' +
      '                <div id="m_EMAIL" class="copy_text">' + empJson.EMAIL + '</div>' +
      '                <i class="material-icons copy_icon">content_copy</i>' +
      '              </div>' +
      '            </div>' +
      '          </div>' +
      '        </div>' +
      '        <div id="contact_details" class="row">' +
      '          <div id="first_col" class="col s7">' +
      /*'            <div class="section">' +
      '              <i class="material-icons">event</i>' +
      '              <div class="icon_val">' +
      '                <h6>DOB</h6>' +
      '                <div id="m_DOB">' + empJson.DOB + '</div>' +
      '              </div>' +
      '            </div>' +*/
      '            <div class="section" id="phone_section">' +
      '              <i class="material-icons">smartphone</i>' +
      '              <div class="icon_val">' +
      '                <h6>Mobile</h6>' +
      '                <div id="m_MOBILE_NO" class="copy_text">' + empJson.MOBILE_NO + '</div>' +
      '                <i class="material-icons copy_icon">content_copy</i>' +
      '              </div>' +
      '            </div>' +
      '            <div class="section">' +
      '              <i class="material-icons">phone</i>' +
      '              <div class="icon_val">' +
      '                <h6>Office No.</h6>' +
      '                <div id="m_OFFICE_NO">' + empJson.OFFICE_NO +
      '                  <span id="m_OTHEROFFICENO">' + empJson.OTHEROFFICENO + '</span>' +
      '                </div>' +
      '              </div>' +
      '            </div>' +
      '            <div class="section">' +
      '              <i class="material-icons">mail</i>' +
      '              <div class="icon_val">' +
      '                <h6>Personal Email</h6>' +
      '                <div id="m_RESIDENTIAL_EMAIL">' + empJson.RESIDENTIAL_EMAIL + '</div>' +
      '              </div>' +
      '            </div>' +
      '          </div>' +
      '          <div id="second_col" class="col s5">' +
      '            <div class="section">' +
      '              <i class="material-icons">public</i>' +
      '              <div class="icon_val">' +
      '                <h6>VPN No.</h6>' +
      '                <div id="m_VPNNO">' + empJson.VPNNO + '</div>' +
      '              </div>' +
      '            </div>' +
      '            <div class="section">' +
      '              <i class="material-icons">print</i>' +
      '              <div class="icon_val">' +
      '                <h6>Fax No.</h6>' +
      '                <div id="m_FAX_NO">' + empJson.FAX_NO + '</div>' +
      '              </div>' +
      '            </div>' +
      '            <div class="section">' +
      '              <i class="material-icons">perm_phone_msg</i>' +
      '              <div class="icon_val">' +
      '                <h6>Residence No.</h6>' +
      '                <div id="m_RESIDENCE_NO">' + empJson.RESIDENCE_NO + '</div>' +
      '              </div>' +
      '            </div>' +
      '          </div>' +
      '        </div>' +
      '        <div id="address_block" class="row section">' +
      '          <i class="material-icons">location_on</i>' +
      '          <h6 class="address_h">Address</h6>' +
      '          <div class="row mar_32">' +
      '            <div id="offcial_address_block" class="col s7">' +
      '              <h6>Communication</h6>' +
      '              <div id="offcial_address">' + office_address + '</div>' +
      '            </div>' +
      '            <div id="res_address_block" class="col s5">' +
      '              <h6>Residential</h6>' +
      '              <div id="res_address">' + res_address + '</div>' +
      '          </div>' +
      '        </div>' +
      '      </div>' +
      '    </div>';
    $('#modal_content').html(modal_content);
    let els1 = document.querySelector('#empDetails_modal');
    let els1Inst = M.Modal.getInstance(els1);
    els1Inst.open();
  }
  public static getBranchDetails(data) {
    EmpSearch.showBranchModal(data);
  }

  public static showBranchModal(branchJson) {
    if (branchJson.BRANCH_NAME) {
      //console.log(JSON.stringify(branchJson,null ,2));
      branchJson.BRANCH_NAME = branchJson.BRANCH_NAME.replace(/\//g, "/ ");

      var branch_address_json = {
        address1: branchJson.ADDRESS1,
        address2: branchJson.ADDRESS2,
        address3: branchJson.ADDRESS3,
        address4: branchJson.ADDRESS4,
        district_name: branchJson.DISTRICT_NAME,
        state_name: branchJson.STATE_NAME,
        address_pin_code: branchJson.ADDRESS_PIN_CODE
      };
      var branch_address = '';
      // tslint:disable-next-line:no-function-expression
      $.each(branch_address_json, function (key, val) {
        branch_address += (val == 'N/A') ? '' : val + ', ';
      });
      branch_address = branch_address.slice(0, -2).replace(/,*,/g, ',');

      var branch_modal_content = '<div id="b_BRANCH_NAME_t" class="bg_branch_code">' + branchJson.BRANCH_CODE + '</div>' +
        '      <div class="row">' +
        '        <div id="branchTop_left" class="col s7">' +
        '          <h4 id="b_BRANCH_NAME">' + branchJson.BRANCH_NAME + '</h4>' +
        '          <div class="col s5 section">' +
        '            <h6>SOL ID</h6>' +
        '            <div id="b_BRANCH_SOLID" class="">' + branchJson.BRANCH_SOLID + '</div>' +
        '          </div>' +
        '          <div class="col s7 section">' +
        '            <h6>Branch Code</h6>' +
        '            <div id="b_BRANCH_CODE">' + branchJson.BRANCH_CODE + '</div>' +
        '          </div>' +
        '        </div>' +
        '        <div id="branchTop_right" class="col s5">' +
        '          <div class="section">' +
        '            <i class="material-icons">phone</i>' +
        '            <div class="icon_val">' +
        '              <h6>Phone No.</h6>' +
        '              <div id="b_PHONE_NO">' + branchJson.PHONE_NO + '</div>' +
        '            </div>' +
        '          </div>' +
        '          <div class="section" id="branch_mail_section">' +
        '            <i class="material-icons">mail_outline</i>' +
        '            <div class="icon_val">' +
        '              <h6>Email</h6>' +
        '              <div id="b_ADDRESS_EMAIL_ADDRESS" class="copy_text">' + branchJson.ADDRESS_EMAIL_ADDRESS + '</div>' +
        '              <i class="material-icons copy_icon">content_copy</i>' +
        '            </div>' +
        '          </div>' +
        '          <div class="section">' +
        '            <i class="material-icons">print</i>' +
        '            <div class="icon_val">' +
        '              <h6>Fax No.</h6>' +
        '              <div id="b_ADDRESS_FAX_NO">' + branchJson.ADDRESS_FAX_NO + '</div>' +
        '            </div>' +
        '          </div>' +
        '        </div>' +
        '      </div>' +
        '      <div class="row">' +
        '        <div id="branchDetails_left" class="col s4">' +
        '          <div class="section">' +
        '            <h6>IFSC Code</h6>' +
        '            <div id="b_BRANCH_IFSC_CODE">' + branchJson.BRANCH_IFSC_CODE + '</div>' +
        '          </div>' +
        '          <div class="section">' +
        '            <h6>MICR Code</h6>' +
        '            <div id="b_BRANCH_MICR_CODE">' + branchJson.BRANCH_MICR_CODE + '</div>' +
        '          </div>' +
        '          <div class="section">' +
        '            <h6>Swift Code</h6>' +
        '            <div id="b_BRANCH_SWIFT_BIC">' + branchJson.BRANCH_SWIFT_BIC + '</div>' +
        '          </div>' +
        '          <div class="section">' +
        '            <h6>RBI Code</h6>' +
        '            <div id="b_BRANCH_RBI_CODE">' + branchJson.BRANCH_RBI_CODE + '</div>' +
        '          </div>' +
        '        </div>' +
        '        <div id="branchDetails_center" class="col s4">' +
        '          <div class="section">' +
        '            <h6>Center Name</h6>' +
        '            <div id="b_CENTRE_NAME">' + branchJson.CENTRE_NAME + '</div>' +
        '          </div>' +
        '          <div class="section">' +
        '            <h6>Region Name</h6>' +
        '            <div id="b_REGION_NAME_FULL">' + branchJson.REGION_NAME_FULL + '</div>' +
        '          </div>' +
        '          <div class="section">' +
        '            <h6>Zone Name</h6>' +
        '            <div id="b_ZONE_NAME_FULL">' + branchJson.ZONE_NAME_FULL +
        '              <span id "b_BRANCH_ZONE_NAME">(' + branchJson.BRANCH_ZONE_NAME + ')</span>' +
        '            </div>' +
        '          </div>' +
        '          <div class="section">' +
        '            <h6>District Name</h6>' +
        '            <div id="b_DISTRICT_NAME">' + branchJson.DISTRICT_NAME +
        '            </div>' +
        '          </div>' +
        '        </div>' +
        '        <div id="branchDetails_right" class="col s4">' +
        '          <div class="section">' +
        '            <h6>Chronological No.</h6>' +
        '            <div id="b_BRANCH_CHRONOLOGICAL_NUMBER">' + branchJson.BRANCH_CHRONOLOGICAL_NUMBER + '</div>' +
        '          </div>' +
        '          <div class="section">' +
        '            <h6>Population Group</h6>' +
        '            <div id="b_BANKTYPE">' + branchJson.BANKTYPE + '</div>' +
        '          </div>' +
        '          <div class="section">' +
        '            <h6>Date of opening</h6>' +
        '            <div id="b_DATE_OPENED">' + branchJson.DATE_OPENED + '</div>' +
        '          </div>' +
        '          <div class="section">' +
        '            <h6>State Name</h6>' +
        '            <div id="b_STATE_NAME">' + branchJson.STATE_NAME + '</div>' +
        '          </div>' +
        '        </div>' +
        '        <div id="branchDetails_address" class="col s8">' +
        '          <div class="section">' +
        '            <h6>Address</h6>' +
        '            <div>' + branch_address +
        '          </div>' +
        '        </div>' +
        '      </div>';
      $('#branch_modal_content').html(branch_modal_content);
      let els2 = document.querySelector('#branchDetails_modal');
      let els2Inst = M.Modal.getInstance(els2);
      els2Inst.open();

    }
  }

  public static copyToClipboard(element) {
    $('#copy_input').val($(element).text()).show();
    $('#copy_input').select();
    document.execCommand("copy");
    $('#copy_input').hide();
  }
}
