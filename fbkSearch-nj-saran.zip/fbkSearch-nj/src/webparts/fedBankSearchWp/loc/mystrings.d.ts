declare interface IFedBankSearchWpWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'FedBankSearchWpWebPartStrings' {
  const strings: IFedBankSearchWpWebPartStrings;
  export = strings;
}
