interface IDesignation{
DESIGCODE:string;
DESIGDESC:string;
SCALE:string;
}
