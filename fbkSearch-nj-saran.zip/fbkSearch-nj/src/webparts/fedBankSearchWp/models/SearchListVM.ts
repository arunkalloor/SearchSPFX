interface ISearchListItemVM {
  NAME: string;
  CODE: string;
  TYPE: string;
}
