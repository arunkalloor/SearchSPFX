interface IDepartment {
  DEPTCODE: string;
  SOLID: string;
  DEPTDESC: string;
}
