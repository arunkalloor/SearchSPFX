/* tslint:disable */
require("./FedBankSearchWpWebPart.module.css");
const styles = {
  fedBankSearchWp: 'fedBankSearchWp_0a1b50d5',
  container: 'container_0a1b50d5',
  row: 'row_0a1b50d5',
  column: 'column_0a1b50d5',
  'ms-Grid': 'ms-Grid_0a1b50d5',
  title: 'title_0a1b50d5',
  subTitle: 'subTitle_0a1b50d5',
  description: 'description_0a1b50d5',
  button: 'button_0a1b50d5',
  label: 'label_0a1b50d5'
};

export default styles;
/* tslint:enable */