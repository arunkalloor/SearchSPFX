export default class htmlMain{
  public static  htmlTemplateStr:string = `
  <div >
    <div class="preloader-wrapper small active">
        <div class="spinner-layer spinner-blue-only">
            <div class="circle-clipper left">
                <div class="circle"></div>
            </div>
            <div class="gap-patch">
                <div class="circle"></div>
            </div>
            <div class="circle-clipper right">
                <div class="circle"></div>
            </div>
        </div>
    </div>

    <!-- Landing Page -->
    <nav>
        <div class="nav-wrapper">
            <a href="#" class="brand-logo center">
                <span class="fed">FED</span> Directory
                <span class="dot">.</span>
            </a>
        </div>
    </nav>

    <div class="searchDiv">

        <form id="searchForm" class="">
            <div class="inner-form">
                <div class="input-field first-wrap">
                    <div class="svg-wrapper">
                        <i class="material-icons">search</i>
                    </div>
                    <input id="searchTxt" type="text" placeholder="Who are you looking for?" autocomplete="off" />
                    <div id="result_count" class=""></div>
                    <div id="clearSearch">
                        <i class="material-icons">close</i>
                    </div>


                </div>
                <div class="input-field second-wrap">
                    <button class="btn-search waves-effect waves-blue"   >SEARCH</button>
                </div>

            </div>
            <span class="info">ex. Employee Name, Branch Code, Employee Code, Branch Name</span>
            <a href="#" class="brand-logo">
                <span class="fed">FED</span> Directory
                <span class="dot">.</span>
            </a>
        </form>
        <div class="footer-copyright center">
            <div class="container">
                <i class="material-icons">copyright</i> Federal Bank 2019
            </div>
        </div>
    </div>

    <!-- #---# -->

    <div class="main-content row hideMe">

    <div class="empList hideMe">
        <div class="row container" style="margin-bottom:0px;">
            <div class="col s12">
                <div class="card-panel">
                    <table id="empList_table" class="highlight">
                        <thead>
                            <tr>
                                <th data-field="code">Code</th>
                                <th data-field="name">Name</th>
                                <th data-field="type">Type</th>
                            </tr>
                        </thead>

                        <tbody></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="container empDetails col s12 l6 hideMe">
        <ul id="empDetails_ul">

        </ul>
    </div>

</div>

    <div id="empDetails_modal" class="modal">
        <div id="modal_content" class="row modal-content">

        </div>
        <div>
            <a  class=" modal-action modal-close waves-effect waves-light btn-flat">
                <i class="material-icons">close</i>
            </a>
        </div>
    </div>

    <div id="branchDetails_modal" class="modal">
        <div id="branch_modal_content" class="row modal-content">

        </div>
        <div>
            <a  class=" modal-action modal-close waves-effect waves-light btn-flat">
                <i class="material-icons">close</i>
            </a>
        </div>
    </div>

    <input id="copy_input" name="copy_input" type="text">

	</div>
  `;

}
