import { sp, Items } from '@pnp/sp';

export class SPConnector {
  private static readonly VCARD_TABLE: string = "FEDBANK_VCARDS";
  private static readonly DEPT_TABLE = "FEDBANK_DEPARTMENT";
  private static readonly BRANCH_TABLE = "FEDBANK_BRANCHDETAILS";

  private searchTable: ISearchListItemVM[];
  private withImageItems: IVcardItem[];

  public getEmpData(queryStr: string, callback: any): string {
    let batch1 = sp.createBatch();
    this.searchTable = [];
    queryStr = encodeURIComponent(queryStr);
    sp.web.lists.getByTitle(SPConnector.VCARD_TABLE).items.select("Title", "DEPARTTMENT/DEPTDESC,NAME").
      expand("DEPARTTMENT").filter(`substringof('${queryStr}',NAME)`).inBatch(batch1).get().then(
        (items: any[]) => {
          //console.log(JSON.stringify(items));
          this.addEmpName(items);
        }
      );

    sp.web.lists.getByTitle(SPConnector.DEPT_TABLE).items.select("Title", "SOLID").filter(`substringof('${queryStr}',SOLID)`).
      inBatch(batch1).get().then((rows: any[]) => { this.addDeptSld(rows); });

    sp.web.lists.getByTitle(SPConnector.DEPT_TABLE).items.select("Title", "DEPTDESC").filter(`substringof('${queryStr}',DEPTDESC)`).
      inBatch(batch1).get().then((rows: any[]) => { this.addDeptDesc(rows); });

    sp.web.lists.getByTitle(SPConnector.DEPT_TABLE).items.select("Title", "DEPTDESC").filter(`substringof('${queryStr}',Title)`).
      inBatch(batch1).get().then((rows: any[]) => { this.addDept03(rows); });

    sp.web.lists.getByTitle(SPConnector.VCARD_TABLE).items.select("Title", "MOBILE_NO").filter(`substringof('${queryStr}',MOBILE_NO)`).
      inBatch(batch1).get().then((items: any[]) => { this.addEmpMob(items); });
    sp.web.lists.getByTitle(SPConnector.VCARD_TABLE).items.select("Title").filter(`substringof('${queryStr}',Title)`).
      inBatch(batch1).get().then((items: any[]) => { this.addEmpPFN(items); });
    sp.web.lists.getByTitle(SPConnector.VCARD_TABLE).items.select("Title", "OFFICE_NO").filter(`substringof('${queryStr}',OFFICE_NO)`).
      inBatch(batch1).get().then((items: any[]) => { this.addEmpOff(items); });


    batch1.execute().then(() => {
      //console.log("batching end..." + JSON.stringify(this.searchTable));
      if ('null' != callback)
        callback(this.searchTable);
      else {
        console.warn("no callback while fetching table data");
      }

    }).catch((e)=>console.error("there was issue getting emp list, aborting"+e));
    return "";
  }

  public getEmpDataM(query: string, callback: any) {
    query = query.replace(/[^0-9a-z]/gi, '');
    query = encodeURIComponent(query);
    sp.web.lists.getByTitle(SPConnector.VCARD_TABLE).items.select("Title", "DEPARTTMENT/DEPTDESC", "BRANCHHEAD", "EMAIL", "CLUB", "ONLEAVE", "SUSPENSION", "ACTIVITIES_HANDLED",
      "RESPONSIBILITY", "NAME", "DESIGNATION/DESIGDESC", "DEPARTTMENT/Title", "OFFICE_NO",
       "OTHEROFFICENO", "MOBILE_NO", "ID","AttachmentFiles").expand("DEPARTTMENT", "DESIGNATION","AttachmentFiles").
      filter(`substringof('${query}',Title) or substringof('${query}',DEPARTTMENT/Title)`).
      orderBy("DESIGNATION/SORTORDER",false).orderBy("SENIORITY",true).orderBy("BRANCHHEAD").get().then(
        (items: any[]) => {
          let data = this.getVcards(items);
          //console.log("fetching employee data...." + JSON.stringify(data));
          if ('null' != callback)
            callback(data, 0);

          else {
            console.warn("no callback available for getEmpDataM");
          }
        });
  }

  public getEmpMoreDetails(query: string, callback: any) {
    query = query.replace(/[^0-9a-z]/gi, '');
    query = encodeURIComponent(query);
    //console.log("query str: " + query);
    sp.web.lists.getByTitle(SPConnector.VCARD_TABLE).items.select("Title", "DEPARTTMENT/DEPTDESC", "NAME", "DESIGNATION/DESIGDESC",
      "RESIDENTIAL_ADDRESS1", "RESIDENTIAL_ADDRESS2", "RESIDENTIAL_ADDRESS2", "RESIDENTIAL_ADDRESS3", "RESIDENTIAL_DISTRICT", "RESIDENTIAL_STATE",
      "RESIDENTIAL_COUNTRY", "RESIDENTIAL_PIN", "OFFICIAL_ADDRESS1", "OFFICIAL_ADDRESS2", "OFFICIAL_ADDRESS3", "OFFICIAL_DISTRICT",
      "STATE_OFFICIAL", "COUNTRY", "OFFICIAL_PIN", "REPORTTINGPF", "REPORTINGPFNO", "ACTIVITIES_HANDLED", "EMAIL", "MOBILE_NO", "OFFICE_NO",
      "OTHEROFFICENO", "RESIDENTIAL_EMAIL", "VPNNO", "FAX_NO", "RESIDENCE_NO", "ID","AttachmentFiles").expand("DEPARTTMENT", "DESIGNATION","AttachmentFiles").
      filter(`'${query}' eq Title`).get().then(
        (items: any[]) => {
          let data = this.fillMoreDetails(items);
          //console.log("fetching More details..." + JSON.stringify(data));
          if ('null' != callback) {
            callback(data);

          } else {
            console.warn("no callback available for getEmpMoreDetails");
          }
        }
      );
  }

  public getBranchDetails(query: string, callback: any) {
    query = query.replace(/[^0-9a-z]/gi, '');
    query = encodeURIComponent(query);
    console.log("getBranchDetails query str: " + query);
    sp.web.lists.getByTitle(SPConnector.BRANCH_TABLE).items.
    filter(`'${query}' eq Title or '${query}' eq BRANCH_SOLID or '${query}' eq BRANCH_NAME`).top(1).get().then(
      (items: any[]) => {
        if( items.length> 0){
          let bcode = items[0].Title;
        let retItem = items[0] as IBranchDetails;
        retItem.BRANCH_CODE = bcode;
        //console.log("branch details has"+ JSON.stringify(retItem));
        callback(retItem);
        }
      }
    );
  }


  private fetchImageForItem(emp: IEmpMoreDetailsVM, callback: any) {
    let pfnum = emp.PFNUM;

    let item = sp.web.lists.getByTitle(SPConnector.VCARD_TABLE).items.getById(emp.ID);
    let imgName = pfnum + ".jpg";
    item.attachmentFiles.getByName(imgName).getBlob().then((data) => {
      emp.imgUrl = URL.createObjectURL(data);
      callback(emp);
    }).catch((e)=>{console.warn("canot fetch image for employee, continuing.."+e);
    callback(emp);
  });

  }

  private async fetchImagesForItems(items: IVcardItem[], callback: any, param: any) {
    this.withImageItems =items;

    if (items.length > 0) {
      //let batch2 = sp.createBatch();
      let promises: Promise<Blob>[] = [];

      items.forEach(elem => {
        let imgStr = elem.PFNUM + ".jpg";
        //console.log(imgStr);
        let fetchProm = sp.web.lists.getByTitle(SPConnector.VCARD_TABLE).items.getById(elem.ID).attachmentFiles.
          getByName(imgStr).getBlob();
        promises.push(fetchProm);
      });

     // Promise.all(promises).
     this.settleAllPromise(promises).
        then(
          (values:any[]) => {
            let i = 0;
            values.forEach(elem  => {
              if('fulfilled'=== elem.state){
              this.withImageItems[i].imgUrl = URL.createObjectURL(elem.value);
              }else{
                console.warn(`there is error fetching ${i}th image,error = ${elem.reason}`);
              }
              i++;
            });
            console.log("all done");
            callback(this.withImageItems, param);
          }
        );
    } else {
      // callback(items, param);
      console.log("not items to get images for");
    }
  }

  private settleAllPromise(promises){
    return Promise.all(promises.map(p => Promise.resolve(p).then(value => ({
      state: 'fulfilled',
      value
    }), reason => ({
      state: 'rejected',
      reason
    }))));

  }

  private getImgSrc(buf: ArrayBuffer) {
    let tar = new Uint8Array(buf);
    let scar = tar.reduce((data, byte) => {
      return data + String.fromCharCode(byte);
    },
      '');
    let b64s = btoa(scar);
    return "data:image/jpg;base64," + b64s;
  }

  private fillMoreDetails(items: any[]): IEmpMoreDetailsVM {
    let moreDetails = {} as IEmpMoreDetailsVM;
    let len = items.length;
    //console.log("items in array:" + len);
    if (len > 0) {
      let elem = items[0];
      let det = {} as IEmpMoreDetailsVM;
      det.RESIDENTIAL_ADDRESS1 = elem['RESIDENTIAL_ADDRESS1'] || "";
      det.RESIDENTIAL_ADDRESS2 = elem['RESIDENTIAL_ADDRESS2'] || "";
      det.RESIDENTIAL_ADDRESS3 = elem['RESIDENTIAL_ADDRESS3'] || "";
      det.RESIDENTIAL_DISTRICT = elem['RESIDENTIAL_DISTRICT'] || "";
      det.RESIDENTIAL_STATE = elem['RESIDENTIAL_STATE'] || "";
      det.RESIDENTIAL_COUNTRY = elem['RESIDENTIAL_COUNTRY'] || "";
      det.RESIDENTIAL_PIN = elem['RESIDENTIAL_PIN'] || "";
      det.OFFICIAL_ADDRESS1 = elem['OFFICIAL_ADDRESS1'] || "";
      det.OFFICIAL_ADDRESS2 = elem['OFFICIAL_ADDRESS2'] || "";
      det.OFFICIAL_ADDRESS3 = elem['OFFICIAL_ADDRESS3'] || "";
      det.OFFICIAL_DISTRICT = elem['OFFICIAL_DISTRICT'] || "";
      det.STATE_OFFICIAL = elem['STATE_OFFICIAL'] || "";
      det.COUNTRY = elem['COUNTRY'] || "";
      det.OFFICIAL_PIN = elem['OFFICIAL_PIN'] || "";
      det.PFNUM = elem['Title'] || "";
      det.NAME = elem['NAME'] || "";
      det.DESIGDESC = elem['DESIGNATION']['DESIGDESC'] || "";
      det.DEPTDESC = elem['DEPARTTMENT']['DEPTDESC'] || "";
      det.REPORTTINGPF = elem['REPORTTINGPF'] || "";
      det.REPORTINGPFNO = elem['REPORTINGPFNO'] || "";
      det.ACTIVITIES_HANDLED = elem['ACTIVITIES_HANDLED'] || "";
      det.EMAIL = elem['EMAIL'] || "";
      det.MOBILE_NO = elem['MOBILE_NO'] || "";
      det.OFFICE_NO = elem['OFFICE_NO'] || "";
      det.OTHEROFFICENO = elem['OTHEROFFICENO'] || "";
      det.RESIDENTIAL_EMAIL = elem['RESIDENTIAL_EMAIL'] || "";
      det.VPNNO = elem['VPNNO'] || "";
      det.FAX_NO = elem['FAX_NO'] || "";
      det.RESIDENCE_NO = elem['RESIDENCE_NO'] || "";
      det.ID = elem["ID"];

      if (typeof elem["AttachmentFiles"] !== 'undefined' && elem["AttachmentFiles"].length > 0){
        det.imgUrl =  elem["AttachmentFiles"][0]["ServerRelativeUrl"];
        }
      moreDetails = det;
    }
    return moreDetails;
  }

  private getVcards(items: any[]): IVcardItem[] {

    let empDetails: IVcardItem[] = [];
    items.forEach(elem => {
      let it = {} as IVcardItem;
      it.PFNUM = elem['Title'];
      it.DEPARTTMENT = elem['DEPARTTMENT']['Title'];
      it.DEPTDESC = elem['DEPARTTMENT']['DEPTDESC'];
      it.BRANCHHEAD = elem['BRANCHHEAD'] || "";
      it.EMAIL = elem['EMAIL'] || "";
      it.CLUB = elem['CLUB'] || "";
      it.ONLEAVE = elem[''] || "";
      it.SUSPENSION = elem[''] || "";
      it.ACTIVITIES_HANDLED = elem['ACTIVITIES_HANDLED'] || "";
      it.RESPONSIBILITY = elem['RESPONSIBILITY'] || "";
      it.NAME = elem['NAME'];
      it.DESIGDESC = elem['DESIGNATION']['DESIGDESC'] || "";
      it.OFFICE_NO = elem['OFFICE_NO'] || "";
      it.OTHEROFFICENO = elem['OTHEROFFICENO'] || "";
      it.MOBILE_NO = elem['MOBILE_NO'] || "";
      it.ID = elem["ID"];
      //console.log( elem["AttachmentFiles"]);
      if (typeof elem["AttachmentFiles"] !== 'undefined' && elem["AttachmentFiles"].length > 0){
      it.imgUrl =  elem["AttachmentFiles"][0]["ServerRelativeUrl"];
      }

      empDetails.push(it);
    });
    return empDetails;
  }

  private addDeptSld(items: any[]) {

    items.forEach(elem => {
      let code = elem['Title'];
      let type = 'SOLID';
      let name = elem['SOLID'];
      let tabItem = {} as ISearchListItemVM;
      tabItem.CODE = code;
      tabItem.NAME = name;
      tabItem.TYPE = type;
      this.searchTable.push(tabItem);
    });
  }

  private addDeptDesc(items: any[]) {
    items.forEach(elem => {
      let code = elem['Title'];
      let type = 'OFFICE';
      let name = elem['DEPTDESC'];
      let tabItem = {} as ISearchListItemVM;
      tabItem.CODE = code;
      tabItem.NAME = name;
      tabItem.TYPE = type;
      this.searchTable.push(tabItem);
    });
  }
  private addDept03(items: any[]) {
    items.forEach(elem => {
      let code = elem['Title'];
      let type = 'Office Code';
      let name = elem['DEPTDESC'];
      let tabItem = {} as ISearchListItemVM;
      tabItem.CODE = code;
      tabItem.NAME = name;
      tabItem.TYPE = type;
      this.searchTable.push(tabItem);
    });
  }
  private addEmpName(items: any[]) {
    items.forEach(elem => {
      let code = elem['Title'];
      let type = 'EMPLOYEE';
      let name = elem['NAME'] + '-' + elem.DEPARTTMENT.DEPTDESC;
      let tabItem = {} as ISearchListItemVM;
      tabItem.CODE = code;
      tabItem.NAME = name;
      tabItem.TYPE = type;
      this.searchTable.push(tabItem);
    });

  }
  private addEmpMob(items: any[]) {
    items.forEach(elem => {
      let code = elem['Title'];
      let type = 'Mobile';
      let name = elem['MOBILE_NO'];
      let tabItem = {} as ISearchListItemVM;
      tabItem.CODE = code;
      tabItem.NAME = name;
      tabItem.TYPE = type;
      this.searchTable.push(tabItem);
    });
  }
  private addEmpPFN(items: any[]) {
    items.forEach(elem => {
      let code = elem['Title'];
      let type = 'Employee';
      let name = elem['Title'];
      let tabItem = {} as ISearchListItemVM;
      tabItem.CODE = code;
      tabItem.NAME = name;
      tabItem.TYPE = type;
      this.searchTable.push(tabItem);
    });
  }
  private addEmpOff(items: any[]) {
    items.forEach(elem => {
      let code = elem['Title'];
      let type = 'Office Num';
      let name = elem['OFFICE_NO'];
      let tabItem = {} as ISearchListItemVM;
      tabItem.CODE = code;
      tabItem.NAME = name;
      tabItem.TYPE = type;
      this.searchTable.push(tabItem);
    });
  }



}
