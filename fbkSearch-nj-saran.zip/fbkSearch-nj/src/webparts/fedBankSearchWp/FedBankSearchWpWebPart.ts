import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

//import styles from './FedBankSearchWpWebPart.module.scss';
import * as strings from 'FedBankSearchWpWebPartStrings';
import { sp } from '@pnp/sp';
import * as  jQuery from 'jquery';

import { SPComponentLoader } from '@microsoft/sp-loader';
import { SPConnector } from './SPDL';
import { EmpSearch } from './EmpSearchHandler';

require('../../../node_modules/material-design-icons/iconfont/material-icons.css');
require('../../../node_modules/materialize-css/dist/css/materialize.min.css');
import * as M from 'materialize-css';

import htmlTemplate from './SearchMainTemplate';
require('./css/main.css');
require('./css/style.css');

declare global {
  interface Window {
    exceuteOnce: Object;
    exceuteOnce_anim;
  }
}


export interface IFedBankSearchWpWebPartProps {
  description: string;
}


export default class FedBankSearchWpWebPart extends BaseClientSideWebPart<IFedBankSearchWpWebPartProps> {

  public spa: SPConnector;

  protected onInit(): Promise<void> {
    return super.onInit().then(
      _ => {
        this.spa = new SPConnector();
        sp.setup({ spfxContext: this.context });
      }
    );
  }


  public render(): void {
    this.domElement.innerHTML = htmlTemplate.htmlTemplateStr;
    EmpSearch.onload();
    this.setupEventHandlers();


  }


  private basicInit() {
    let elems = document.querySelectorAll('.materialboxed');
    M.Materialbox.init(elems);

  let elems2 = document.querySelectorAll('.modal');
  M.Modal.init(elems2, {
      dismissible: true, // Modal can be dismissed by clicking outside of the modal
      opacity: .5, // Opacity of modal background
      inDuration: 300, // Transition in duration
      outDuration: 200, // Transition out duration
      startingTop: '4%', // Starting top style attribute
      endingTop: '10%' // Ending top style attribute
    });

    let elem3 = document.querySelectorAll('.scrollspy');
    M.ScrollSpy.init(elem3);
    /****
     Jquery easing
     easeInOutExpo
     for aniamtion
     ******/
    jQuery.easing['jswing'] = jQuery.easing['swing'];

    jQuery.extend(jQuery.easing, {
      easeInOutExpo:  (x, t, b, c, d) =>{
        if (t == 0) return b;
        if (t == d) return b + c;
        if ((t /= d / 2) < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
        return c / 2 * (-Math.pow(2, -10 * --t) + 2) + b;
      }
    });
    /*animation end*/


    window.exceuteOnce = true;
    window.exceuteOnce_anim = true;
  }

  private setupEventHandlers() {
    this.basicInit();
    EmpSearch.onload();
    $('.btn-search').on('click', (e) => {
      e.preventDefault();
      if ($('#searchTxt').val() && $('#searchTxt').val().toString().length > 1) {
        let query: string = $('#searchTxt').val().toString().toUpperCase();
        $("#result_count").html('');
        $('.main-content,.preloader-wrapper').show();
        this.spa.getEmpData(query, EmpSearch.getEmpList);
      } else {
        //** no value entered */
        alert('Minimun two characters required.');
      }
    });

    $('#empList_table').on('click', '.list', (e) => {
      var code = $(e.currentTarget).attr('data-code').toUpperCase();
      this.spa.getEmpDataM(code, EmpSearch.getEmpDetails);
      $('#empDetails_ul').scrollTop(0);
    });

    $('#searchTxt').on('keyup', (e) => {
      if (e.keyCode == 13) {
        $("#clearSearch i").removeClass("anim_close");
      } else if ($('#searchTxt').val()) {
        if (!$("#clearSearch i").hasClass("anim_close"))
          $("#clearSearch i").addClass("anim_close");
        $('.info').html("Press 'Enter' to search");
        $("#result_count").html('');
      } else {
        $("#clearSearch i").removeClass("anim_close");
        $('.info').html("ex. Name, Branch Code, Emp Code, Branch Name");
        $("#result_count").html('');
      }

    });
    $('#searchTxt').on('focusin', () => {
      if ($('#searchTxt').val()) {
        if (!$("#clearSearch i").hasClass("anim_close"))
          $("#clearSearch i").addClass("anim_close");
        $("#result_count").html('');
        $('.info').html("Press 'Enter' to search");
      }
    });

    $('#searchTxt').on('focusout', () => {
      $("#clearSearch i").removeClass("anim_close");
      $('.info').html("ex. Name, Branch Code, Emp Code, Branch Name");
    });

    $('#clearSearch').on('mousedown', 'i', () => {
      $('#searchTxt').val('');
      $("#clearSearch i").removeClass("anim_close");
      $('.info').html("ex. Name, Branch Code, Emp Code, Branch Name");
    });


    $('#empDetails_ul').on('click', '.card-action', (e) => {
      var empcode = $(e.currentTarget).attr('data-empcode').toUpperCase();
      //console.log("More details" + empcode);
      this.spa.getEmpMoreDetails(empcode, EmpSearch.getMoreEmpDetails);
    });

    $('.modal-content,#empDetails_ul').on('click', '.copy_text', (e) => {
      EmpSearch.copyToClipboard($(e.currentTarget));

      switch ($(e.currentTarget).attr('id')) {
        case "EMAIL":
          M.toast({ html: 'Mail Id copied', displayLength: 3000, classes: 'rounded' });
          break;
        case "m_EMAIL":
          M.toast({ html: 'Mail Id copied', displayLength: 3000, classes: 'rounded custom_toast' });
          break;
        case "MOBILE_NO":
          M.toast({ html: 'Mobile No. copied', displayLength: 3000, classes: 'rounded' });
          break;
        case "m_MOBILE_NO":
          M.toast({ html: 'Mobile No. copied', displayLength: 3000, classes: 'rounded custom_toast' });
          break;
        case "b_ADDRESS_EMAIL_ADDRESS":
          M.toast({ html: 'Mail Id copied', displayLength: 3000, classes: 'rounded custom_toast' });
          break;

      }
    });

    $('#empList_table,#empDetails_ul').on('click', '.get_BrnchDetails', (e) => {
      var branch = $(e.currentTarget).attr('data-branch').toUpperCase();
      this.spa.getBranchDetails(branch,EmpSearch.getBranchDetails);

    });

  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
